// src/components/CompanionTabText.jsx
import React from 'react';
import './CompanionTabText.css';

const CompanionTabText = () => {
  return (
    <span className="companion-tab-text tab-label">
      Agent
    </span>
  );
};

export default CompanionTabText;